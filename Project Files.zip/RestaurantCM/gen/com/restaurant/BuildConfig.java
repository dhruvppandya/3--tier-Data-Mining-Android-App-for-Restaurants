/** Automatically generated file. DO NOT MODIFY */
package com.restaurant;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}