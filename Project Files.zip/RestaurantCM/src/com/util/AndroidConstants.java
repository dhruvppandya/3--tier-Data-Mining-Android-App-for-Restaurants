/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.util;


public class AndroidConstants {

	public static UserAccount currentUser=null;
    public static String SERVER_IP="192.168.0.104";
    public static String SERVER_PORT="9898";
    public static String url() { 
    	return "http://"+AndroidConstants.SERVER_IP+":"+AndroidConstants.SERVER_PORT+"";
    }
    public static final int ROLE_ADMIN=2;
    public static final int ROLE_KITCHEN=3;
    public static final int ROLE_USER=1;
    
    
}
