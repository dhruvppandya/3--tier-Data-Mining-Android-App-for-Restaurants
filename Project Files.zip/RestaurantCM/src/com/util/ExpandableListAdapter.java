package com.util;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.restaurant.R;
import com.restaurant.SuggestionsActivity;

public class ExpandableListAdapter extends BaseExpandableListAdapter {

	private Context context;
	private ArrayList<HashMap> groups;
	private ArrayList<ArrayList<MenuItem>> menuItemList;
	private LayoutInflater inflater;

	public ExpandableListAdapter(Context context, ArrayList<HashMap> groups,
			ArrayList<ArrayList<MenuItem>> menuItemList) {
		this.context = context;
		this.groups = groups;
		this.menuItemList = menuItemList;
		inflater = LayoutInflater.from(context);
	}

	public Object getChild(int groupPosition, int childPosition) {
		return menuItemList.get(groupPosition).get(childPosition);
	}

	public long getChildId(int groupPosition, int childPosition) {
		return (long) (groupPosition * 1024 + childPosition); // Max 1024
																// children per
																// group
	}

	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		View v = null;
		if (convertView != null)
			v = convertView;
		else
			v = inflater.inflate(R.layout.child_row, parent, false);
		MenuItem c = (MenuItem) getChild(groupPosition, childPosition);
		TextView title = (TextView) v.findViewById(R.id.textView1111);
		TextView desc= (TextView) v.findViewById(R.id.textView2);
		TextView price= (TextView) v.findViewById(R.id.textView3);
		CheckBox itemSelected= (CheckBox) v.findViewById(R.id.checkBox1);
		title.setText(c.getItemTitle());
		desc.setText(c.getItemDesc());
		price.setText(c.getItemPrice());
		if(context instanceof SuggestionsActivity){
			itemSelected.setSelected(false);
			itemSelected.setVisibility(CheckBox.INVISIBLE);
		}
		itemSelected.setTag(c);
		return v;
	}

	public int getChildrenCount(int groupPosition) {
		return menuItemList.get(groupPosition).size();
	}

	public Object getGroup(int groupPosition) {
		return groups.get(groupPosition);
	}

	public int getGroupCount() {
		return groups.size();
	}

	public long getGroupId(int groupPosition) {
		return (long) (groupPosition * 1024); // To be consistent with
												// getChildId
	}

	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		View v = null;
		if (convertView != null)
			v = convertView;
		else
			v = inflater.inflate(R.layout.group_row, parent, false);
		HashMap gt = (HashMap) getGroup(groupPosition);
		String catagoryDesc=StringHelper.n2s(gt.get("catagoryDesc"));
		
		TextView menuItemGroup = (TextView) v.findViewById(R.id.childname);
		if (catagoryDesc != null)
			menuItemGroup.setText(catagoryDesc);
		return v;
	}

	public boolean hasStableIds() {
		return true;
	}

	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	public void onGroupCollapsed(int groupPosition) {
	}

	public void onGroupExpanded(int groupPosition) {
	}

}
