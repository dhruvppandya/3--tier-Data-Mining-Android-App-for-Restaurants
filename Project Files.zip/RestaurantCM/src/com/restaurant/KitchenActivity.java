package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.util.AndroidConstants;
import com.util.HttpView;
import com.util.MenuItem;
import com.util.StringHelper;

public class KitchenActivity extends CommonActivity {

	ExpandableListView elv = null;
	boolean isBill=false;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.kitchenmenu);
		isBill=getIntent().getBooleanExtra("BILL", false);
		populateOrderList();
	        
		

	}
	public ArrayList getTodaysPendingOrder() {
		ArrayList arr = new ArrayList();
		HashMap param = new HashMap();
		param.put("method", "getTodaysPendingOrder");
		if(isBill){
			param.put("userId", AndroidConstants.currentUser.getUserid());
	}
		arr = HttpView.getArrayServer(param);
		System.out.println("Got the TodaysPendingOrder "
				+ arr.size());
		return arr;
	}
	void populateOrderList() {
		HashMap itemNameMap=new HashMap();
		
		LinearLayout tl=(LinearLayout)findViewById(R.id.linearLayout1);
		ArrayList menu=getMenuList();
		for (Iterator iterator = menu.iterator(); iterator.hasNext();) {
			HashMap menuItem = (HashMap) iterator.next();
			String itemTitle =StringHelper.n2s(menuItem.get("itemTitle"));
			String itemPrice =StringHelper.n2s(menuItem.get("itemPrice"));
			String menuId =StringHelper.n2s(menuItem.get("menuId"));
			itemNameMap.put(menuId, itemTitle+"#"+itemPrice);
		}
		
		ArrayList arr=getTodaysPendingOrder();
		int total=0;
		for (int j = 0; j < arr.size(); j++) {
			HashMap param=(HashMap)arr.get(j);
			System.out.println("param "+param);
			Log.v("KitchenActivty", "param "+param);
			String orderid=StringHelper.n2s(param.get("orderid")) ;
			String tm=StringHelper.n2s(param.get("tm")) ;
			
			String menuitemids=StringHelper.n2s(param.get("menuitemids"));
			String menuitemquantity=StringHelper.n2s(param.get("menuitemquantity"));
			String tableNo=StringHelper.n2s(param.get("tableNo"));
			int orderstatus=StringHelper.nullObjectToIntegerEmpty(param.get("orderstatus"));
			
			LinearLayout row = (LinearLayout)LayoutInflater.from(KitchenActivity.this).inflate(R.layout.kitchenmenurow, null);
			TableLayout tableLayout=(TableLayout)row.findViewById(R.id.tableLayout1);
			final TextView orderno= (TextView)row.findViewById(R.id.textViewOrderNo);
			if(!isBill)
			orderno.append(" : "+orderid+"      Table : "+tableNo+" "+tm);
			else{
				if(orderstatus==0)
					orderno.append(" : "+orderid+"      Table : "+tableNo+" "+tm+" Pending");
				else if(orderstatus==1)
					orderno.append(" : "+orderid+"      Table : "+tableNo+" "+tm+" Delivered");
				else
					orderno.append(" : "+orderid+"      Table : "+tableNo+" "+tm);
			}
			
			TextView itemsTextView= (TextView)row.findViewById(R.id.itemsTextView);
			String itemids[]=menuitemids.split(",");
			String itemqty[]=menuitemquantity.split(",");
			itemsTextView.setText("");
			int finalTotal=0;
			for (int i = 0; i < itemqty.length; i++) {
				String itemid=itemids[i];
				String itemq=itemqty[i];
				String nameprice=StringHelper.n2s(itemNameMap.get(itemid)) ;
				String nm[]=nameprice.split("#");
				int price=StringHelper.nullObjectToIntegerEmpty(nm[1]);
				int qty=StringHelper.nullObjectToIntegerEmpty(itemq);
				int total1=price*qty;
				StringBuffer sb;
		  		String n=nm[0].trim();
				Log.v("KitchenActivty", n.length()+"--");
				StringBuffer sb1=new StringBuffer("");
				sb1.append((i+1)+" ");
				if(!isBill){
				sb1.append(" "+itemq+"  ");
				sb1.append(n);
				}else{
					StringBuffer nm121=new StringBuffer(n);
					
					Log.v("KitchenActivty", nm121+"--");
					n=padRight(n
							, 20);
					System.out.println(n+"-");
					sb1.append(n);
					sb1.append(" "+itemq+"  ");
					sb1.append(" "+total1+"  ");
				}

					
				
				sb1.append("\n");
				
				
			
				Log.v("KitchenActivty", sb1+"-");
				
				finalTotal+=total1;
//					itemsTextView.append((i+1)+"  "+nm[0]+"    "+itemq+"    "+total1+"\r\n");
//					itemsTextView.append(sb1);
				
				TableRow tr=new TableRow(KitchenActivity.this);
				tr.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
				TextView srno=new TextView(KitchenActivity.this);
				srno.setText(" "+(i+1)+" ");
				
				TextView na=new TextView(KitchenActivity.this);
				na.setText(" "+n+" ");
				
				TextView qty1=new TextView(KitchenActivity.this);
				qty1.setText(" "+qty+"");
			
				tr.addView(srno);
				tr.addView(na);
				tr.addView(qty1);
			if(isBill){
				TextView total1tc=new TextView(KitchenActivity.this);
				total1tc.setText(" "+total1+"");
			
				tr.addView(total1tc);
			}
				tableLayout.addView(tr);
    				   
			}
			if(isBill){
//			itemsTextView.append("   Total             "+finalTotal+"\r\n");
				
				TableRow tr=new TableRow(KitchenActivity.this);
				tr.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
				TextView srno=new TextView(KitchenActivity.this);
				srno.setText("  ");
				
				TextView na=new TextView(KitchenActivity.this);
				na.setText(" Total ");
				
				TextView qty1=new TextView(KitchenActivity.this);
				qty1.setText(" "+finalTotal+"");
				
				tr.addView(srno);
				tr.addView(na);
				tr.addView(qty1);
				tableLayout.addView(tr);
			}
			
			ImageButton imageButton= (ImageButton)row.findViewById(R.id.imageButton1);
			imageButton.setTag(orderid);
			imageButton.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					ImageButton b=(ImageButton)v;
					String orderid=b.getTag().toString();
					if(!isBill){
					HashMap param = new HashMap();
					param.put("method", "updateOrderStatus");
					param.put("orderId", orderid);
					param.put("status", "1");
					String d = HttpView.getData(param);
					orderno.append("   Delivered " );
					b.setEnabled(false);
					}else{
						toast("Pay by Cash");
					}
				}
			});
			
//			tl.addView(row, new ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));	
//			tl.addView(row);
			
//			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j);
//			((TextView)row.findViewById(R.id.textView1)).setText((j+1)+"");
//		    ((TextView)row.findViewById(R.id.textView2)).setText(mi.getItemTitle());
//		   
//		    ((TextView)row.findViewById(R.id.textView4)).setText(mi.getItemPrice());
//		    int price=StringHelper.nullObjectToIntegerEmpty(mi.getItemPrice());
//		    int quantity=StringHelper.nullObjectToIntegerEmpty(mi.getItemQuantity());
//		    total+=price*quantity;
//		    ((EditText)row.findViewById(R.id.editTextQuantity)).setText(quantity+"");
//		    ((EditText)row.findViewById(R.id.editTextQuantity)).addTextChangedListener(new TextWatcher() {
//				
//				public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
//					// TODO Auto-generated method stub
//					 reCalculateTotal();
//					 toast("Text Changed");
//					
//				}
//				
//				public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
//						int arg3) {
//					// TODO Auto-generated method stub
//					
//				}
//				
//				public void afterTextChanged(Editable arg0) {
//					// TODO Auto-generated method stub
//					
//				}
//			});
		    tl.addView(row);
//		    
//		}
//		
//		TableRow row = (TableRow)LayoutInflater.from(KitchenActivity.this).inflate(R.layout.row, null);
//		
//		((TextView)row.findViewById(R.id.textView1)).setText(" ");
//	    ((TextView)row.findViewById(R.id.textView2)).setText("Total ");
//	    ((TextView)row.findViewById(R.id.textView4)).setText(total+"");
//	    ((EditText)row.findViewById(R.id.editTextQuantity)).setVisibility(EditText.INVISIBLE);
	    
	}
	}
	public static String padRight(String s, int n) {
	     return String.format("%1$-" + n + "s", s);  
	}

	public static String padLeft(String s, int n) {
	    return String.format("%1$" + n + "s", s);  
	}
	private void reCalculateTotal() {
		TableLayout tl=(TableLayout)findViewById(R.id.tableLayout1);
		
		
		int total=0;
		int j =1;
		for (j = 1; j <tl.getChildCount()-1; j++) {
			TableRow row = (TableRow) tl.getChildAt(j);
			String q= ((EditText)row.findViewById(R.id.editTextQuantity)).getText().toString();
			int quantity=StringHelper.nullObjectToIntegerEmpty(q);
			if(quantity>0){
			
			
			String p= ((TextView)row.findViewById(R.id.textView4)).getText().toString();
			int price=StringHelper.nullObjectToIntegerEmpty(p);
			  total+=price*quantity;
			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j-1);
			mi.setItemQuantity(quantity);
			
			}else{
				toast("Please enter quantity");
			}
			
			
		}
		TableRow row = (TableRow) tl.getChildAt(j);
		 ((TextView)row.findViewById(R.id.textView4)).setText(total+"");
	}
	
	public void saveOrder(View v){
		
		String itemId="";
		String itemQunaity="";
		
		int total=0;
		for (int j = 0; j < RestaurantCMActivity.orders.size(); j++) {
			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j);
			itemId+=","+mi.getMenuId();
			itemQunaity+=","+mi.getItemQuantity();
					
			int price=StringHelper.nullObjectToIntegerEmpty(mi.getItemPrice());
			int quantity=StringHelper.nullObjectToIntegerEmpty(mi.getItemQuantity());
			total+=price*quantity;
		}
		if(itemId.length()>0){
			itemId=itemId.substring(1);
		}
		
		
		saveOrder(itemId,itemQunaity,total,AndroidConstants.currentUser.getUserid());
		
	}
	public void saveOrder(String menuitemids,String menuitemQuantity,int totalamount,String userid) {
		HashMap param = new HashMap();
		param.put("method", "saveOrder");
		param.put("menuitemids", menuitemids);
		param.put("totalamount", totalamount);
		param.put("itemsquantity", menuitemQuantity);
		param.put("userid", userid);

		String data = HttpView.connectToServer(HttpView.createURL(param));
		if(data.length()>0&&data.equalsIgnoreCase("true")){
			toast("Order Saved Successfully!!!");
			RestaurantCMActivity.orders= new ArrayList();
			
			go(RestaurantCMActivity.class);
		}else{
			toast("Unable to place order at this time!");
		}
	}

	

}