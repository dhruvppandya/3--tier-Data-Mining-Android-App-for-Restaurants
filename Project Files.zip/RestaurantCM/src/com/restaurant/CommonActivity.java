package com.restaurant;

import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.util.AndroidConstants;
import com.util.HttpView;
import com.util.StringHelper;

public class CommonActivity extends Activity {
	
	public void go(Class c){
		Intent intent = new Intent(CommonActivity.this,
				c);
		startActivity(intent);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		
		MenuItem branchSuggestions= menu.findItem(R.id.branchSuggestions);
		MenuItem menuPlaceOrder= menu.findItem(R.id.menuPlaceOrder);
		MenuItem menuCustomized= menu.findItem(R.id.menuCustomized);
		MenuItem menuSuggestions= menu.findItem(R.id.menuSuggestions);
		MenuItem menuBill= menu.findItem(R.id.menuBill);
		MenuItem kitchenWindow= menu.findItem(R.id.kitchenWindow);
		
		
		if(AndroidConstants.currentUser.getRoleid().equalsIgnoreCase(AndroidConstants.ROLE_ADMIN+"")){	// 1= Admin
		//	System.out.println("In admin");
				menuPlaceOrder.setVisible(false);
				menuCustomized.setVisible(false);
				menuBill.setVisible(false);
		}else if(AndroidConstants.currentUser.getRoleid().equalsIgnoreCase(AndroidConstants.ROLE_KITCHEN+"")){	// kitchen
				menuCustomized.setVisible(false);
				menuPlaceOrder.setVisible(false);
				menuBill.setVisible(false);
				branchSuggestions.setVisible(false);
				menuSuggestions.setVisible(false);
		}else {	//user
			branchSuggestions.setVisible(false);
			kitchenWindow.setVisible(false);
			menuSuggestions.setVisible(false);
		}
		
		return true;
	}
	public void refresh() {

	}
	public ArrayList getMenuList() {
		ArrayList arr = new ArrayList();
		HashMap param = new HashMap();
		param.put("method", "menu");
		arr  = HttpView.getArrayServer(param);
		System.out.println("Got the menuList "
				+ arr.size());
		return arr;
	}

	public ArrayList getCatagories() {
		ArrayList arr = new ArrayList();
		HashMap param = new HashMap();
		param.put("method", "catagories");
		arr= HttpView.getArrayServer(param);
		System.out.println("Got the getCatagories "
				+ arr.size());
		return arr;
	}
	public  String getIMEI(){
		  TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
	        String imei=telephonyManager.getDeviceId();
	        System.out.println("Device IMEI is "+imei);
	        return imei;
	        
	}
	
	public void toast(String message) {
		Toast t = Toast.makeText(CommonActivity.this, message, 3000);
		t.show();
	}
	public static boolean serviceRunning=false;
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent main = null;
		switch (item.getItemId()) {
		case R.id.menuMain:
			toast("Main Menu");
			Intent in = new Intent(CommonActivity.this,
					RestaurantCMActivity.class);
			startActivity(in);
			break;
		case R.id.menuCustomized:
			toast("Customized Menu");
			Intent intent = new Intent(CommonActivity.this,
					SuggestionsActivity.class);
			intent.putExtra("CUSTOMIZED",true);
			startActivity(intent);
			refresh();
			break;
		case R.id.menuPlaceOrder:
			toast("Place Order ");
			go(PlaceOrderActivity.class);
			break;
			
		case R.id.kitchenWindow:
			go(KitchenActivity.class);
		break;
		case R.id.menuBill:
			Intent intent1 = new Intent(CommonActivity.this,
					KitchenActivity.class);
			intent1.putExtra("BILL", true);
			startActivity(intent1);
			break;
		case R.id.branchSuggestions:
			toast("Branch Suggestions");
			final EditText input = new EditText(CommonActivity.this);
			input.setRawInputType(InputType.TYPE_CLASS_NUMBER);
			new AlertDialog.Builder(CommonActivity.this)
		    .setTitle("Branch Suggestions")
		    .setMessage("Enter Order Amount")
		    .setView(input)
		    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int whichButton) {
		            Editable value = input.getText();
		            if(value.toString().length()>0){
		            	HashMap param = new HashMap();
		        		param.put("method", "getBranchOpening");
		        		param.put("amount", value.toString());
		        		Object o= HttpView.connect2ServerObject(HttpView.createURL(param));
		        		System.out.println("o "+o);
		        		if(o instanceof ArrayList){
		        			ArrayList e=(ArrayList)o;
		        			if(e.size()>0){
		        				HashMap m=(HashMap) e.get(0);
		        				String address =StringHelper.n2s(m.get("address"));
		        				String cnt =StringHelper.n2s(m.get("cnt"));
		        				
		        				
		        				toast("New Branch can be opened at "+address+" Customer Count is "+cnt);
		        			}
		        		}
		        		
		            
		            }else{
		            	toast("Please enter amount");
		            }
		            
		        }
		    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int whichButton) {
		            // Do nothing.
		        }
		    }).show();
			break;	
		case R.id.menuSuggestions:
			toast("Suggestions Menu");
//			HashMap param = new HashMap();
//			param.put("method", "calculateAprioriCombinations");
//			try{
//				String data = HttpView.connectToServer(HttpView.createURL(param));
//				String[] db= data.split("#");
//				toast("Total Transactions are "+db[0]);
//				toast("Minimum Support is "+db[1]);
//				toast("Probable Combination is "+db[2]);
//				toast(" Frequency "+db[3]);
//			}catch (Exception e) {
//				e.printStackTrace();
//			}
			go(SuggestionsActivity.class);
			break;
				
		case R.id.settings:
			main = new Intent(getApplicationContext(), ConfigTabActivity.class);
			startActivity(main);
			break;
		case R.id.exit:
			Toast.makeText(this, "You pressed exit!", Toast.LENGTH_SHORT)
					.show();
			finished();
			break;

		

		}
		return true;
	}

	public void finished() {
		try {
			super.finish();
			super.onDestroy();

			AndroidConstants.currentUser=null;
			System.runFinalizersOnExit(true);
			finish();
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);
			android.os.Process.killProcess(android.os.Process.myPid());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	ProgressDialog progressDialog = null;
	AlertDialog alertDialog1 = null;


	public static ServerSocket ss = null;


	AlertDialog alertDialog;

	class CheckConnectivityAsyncTask extends AsyncTask<String, String, String> {
		String message = "";
		String title = "";
		String action = "";

		@Override
		protected void onPreExecute() {
			System.out.println("In Aysnc");
			progressDialog = ProgressDialog.show(CommonActivity.this,
					"Please Wait", "Loading....", true);
			alertDialog = new AlertDialog.Builder(CommonActivity.this).create();
		}

		@Override
		protected String doInBackground(String... params) {
			String ip = params[0];
			int port = StringHelper.nullObjectToIntegerEmpty(params[1]);
			boolean success = HttpView.checkConnectivityServer(ip, port);

			if (success) {

				title = "Success";
				if (params.length > 2 && params[2].equalsIgnoreCase("UpdateIp")) {
					action = "1";
					message = "Connection established with the Main Server.";
					AndroidConstants.SERVER_IP = ip;
					AndroidConstants.SERVER_PORT = port + "";
				} else {
					message = "Internet Connection Successful!";
				}
			} else {
				action = "";
				message = "Error Connecting to Server http://" + ip + ":"
						+ port;
				title = "Connectivity Error";
			}

			return success + "";
		}

		@Override
		protected void onPostExecute(String result) {
			progressDialog.dismiss();
			alertDialog.setTitle(title);
			alertDialog.setMessage(message);
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					alertDialog.hide();
					if (action.length() > 0) {
						Intent main = new Intent(CommonActivity.this,
								WelcomeActivity.class);
						startActivity(main);
					}

				}
			});
			alertDialog.show();

		};

	}

	public ListView listViewPcList;
	public ListView listViewProcessList;

}
