package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.util.AndroidConstants;
import com.util.ExpandableListAdapter;
import com.util.MenuItem;
import com.util.StringHelper;

public class RestaurantCMActivity extends CommonActivity {

	ExpandableListView elv = null;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		elv = (ExpandableListView) findViewById(R.id.expandableList);
		
		RestaurantCMActivity.menuList =getMenuList();
		RestaurantCMActivity.catagoryList=getCatagories();
		setListAdapter();

	}

	ExpandableListAdapter expListAdapter = null;

	public void setListAdapter() {

		expListAdapter = new ExpandableListAdapter(RestaurantCMActivity.this,
				RestaurantCMActivity.catagoryList,
				getCatagoryWiseData(RestaurantCMActivity.menuList));
		elv.setAdapter(expListAdapter);

	}


	public void onClick(View v) {
		System.out.println("View " + v.getParent());

		if (v.getParent() instanceof RelativeLayout) {
			CheckBox c = (CheckBox) v;
			if (c.isChecked()) {

				RelativeLayout rl = (RelativeLayout) v.getParent();
				System.out.println(((TextView) rl.findViewById(R.id.textView2))
						.getText());
				System.out.println(v.getTag());
				MenuItem mi = (MenuItem) v.getTag();
				orders.add(mi);
			
			}else{
				
				MenuItem mi = (MenuItem) v.getTag();
				for (int i=0;i<orders.size();i++) {
					MenuItem miter= (MenuItem) orders.get(i);
					if(miter==mi){
						orders.remove(i);
					}
				}
			}
		}
		System.out.println("orders Size "+orders.size());
	}

	public static ArrayList orders = new ArrayList();

	@Override
	public void onContentChanged() {
		// TODO Auto-generated method stub
		super.onContentChanged();
		toast("onContentChanged ");
	}

	public static HashMap imgMap = new HashMap();

	public ArrayList getCatagoryWiseData(ArrayList menuItems) {
		ArrayList<ArrayList> result = new ArrayList<ArrayList>();
		for (int i = 0; i < catagoryList.size(); i++) {
			HashMap bu = (HashMap) catagoryList.get(i);
			String catagory = StringHelper.nullObjectToStringEmpty(bu
					.get("catagoryId"));
			ArrayList<MenuItem> arr = new ArrayList<MenuItem>();
			for (int j = 0; j < menuList.size(); j++) {
				HashMap param = (HashMap) menuList.get(j);
				String cata = StringHelper.nullObjectToStringEmpty(param
						.get("catagory"));
				String itemTitle = StringHelper.nullObjectToStringEmpty(param
						.get("itemTitle"));

				String itemDesc = StringHelper.nullObjectToStringEmpty(param
						.get("itemDesc"));
				String menuId = StringHelper.nullObjectToStringEmpty(param
						.get("menuId"));
				String itemPrice = StringHelper.nullObjectToStringEmpty(param
						.get("itemPrice"));
				
				MenuItem mi = new MenuItem();
				mi.setCatagory(cata);
				mi.setItemTitle(itemTitle);
				mi.setItemDesc(itemDesc);
				mi.setItemPrice(itemPrice);
				mi.setMenuId(menuId);
				String prepTime = StringHelper.nullObjectToStringEmpty(param	
						.get("prepTime"));
				mi.setPrepTime(prepTime);
				mi.setItemQuantity(1);
				System.out.println("i " + i + " catagory " + catagory
						+ " Cata " + cata);
				if (cata.equalsIgnoreCase(catagory)) {

					arr.add(mi);
				}

			}
			result.add(arr);
		}
		return result;
	}

	
@Override
protected void onResume() {
	// TODO Auto-generated method stub
	super.onResume();
	if(AndroidConstants.currentUser==null){
		go(WelcomeActivity.class);
	}
	
	
}
	public static final String LOG_TAG = "DomainActivity ";
	public static ArrayList menuList = new ArrayList();
	public static ArrayList catagoryList = new ArrayList();

}