package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.util.HttpView;

public class RegisterActivity extends CommonActivity {
	EditText name, email, phone, address;
	DatePicker dob, doa;
	RadioGroup radioGroup;
	RadioButton single, married;
	TextView anniversary;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		name = (EditText) findViewById(R.id.editText1);
		email = (EditText) findViewById(R.id.editText2);
		phone = (EditText) findViewById(R.id.editText3);
		address = (EditText) findViewById(R.id.editText4);
		radioGroup = (RadioGroup) findViewById(R.id.radioGroup1);
		anniversary = (TextView) findViewById(R.id.TextView01);
		dob = (DatePicker) findViewById(R.id.datePicker1);
		doa = (DatePicker) findViewById(R.id.datePicker2);
		single = (RadioButton) findViewById(R.id.radioButton1);
		married = (RadioButton) findViewById(R.id.radioButton2);
		radioGroup.setOnCheckedChangeListener(onCheck);

		single.setOnClickListener(maritalStatusListener);
		married.setOnClickListener(maritalStatusListener);

	}
	RadioGroup.OnCheckedChangeListener onCheck = new RadioGroup.OnCheckedChangeListener() {

		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			switch (checkedId) {
			case R.id.radioButton1:
				anniversary.setVisibility(View.GONE);
				doa.setVisibility(View.GONE);
				break;
			case R.id.radioButton2:
				anniversary.setVisibility(View.VISIBLE);
				doa.setVisibility(View.VISIBLE);
				break;
			default:
				break;
			}

		}
	};

	RadioButton.OnClickListener maritalStatusListener = new RadioButton.OnClickListener() {

		public void onClick(View v) {
			if (single.isChecked()) {
				da = "";
			} else {
				da = doa.getDayOfMonth() + "-" + doa.getMonth() + "-"
						+ doa.getYear();
			}
		}
	};
	String da = "";

	public void register(View v) {
		ArrayList arr = new ArrayList();
		HashMap param = new HashMap();
		param.put("method", "registerCustomer");
		param.put("cname", name.getText().toString());
		param.put("emailid", email.getText().toString());
		param.put("caddress", address.getText().toString());
		param.put("phoneno", phone.getText().toString());
		param.put("imei", getIMEI());
		String db = dob.getDayOfMonth() + "-" + dob.getMonth() + "-"
				+ dob.getYear();
		String da = doa.getDayOfMonth() + "-" + doa.getMonth() + "-"
				+ doa.getYear();
		param.put("dob", db);
		param.put("doa", da);

		String result = HttpView.connectToServer(HttpView.createURL(param));
		if(result.equalsIgnoreCase("true")){
			toast("User Registered Successfully!!");
			go(WelcomeActivity.class);
		}
		else
			toast("Error in Registration. Try Again Later.");

	}

}