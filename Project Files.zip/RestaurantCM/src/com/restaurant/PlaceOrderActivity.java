package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.util.AndroidConstants;
import com.util.HttpView;
import com.util.MenuItem;
import com.util.StringHelper;
import com.util.UserAccount;

public class PlaceOrderActivity extends CommonActivity {

	ExpandableListView elv = null;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.placeorder);
		populateOrderList();
	        
		

	}
	int totalTimeInMin=0;
	private void populateOrderList() {
		TableLayout tl=(TableLayout)findViewById(R.id.tableLayout1);
		
		
		int total=0;
		for (int j = 0; j < RestaurantCMActivity.orders.size(); j++) {
			TableRow row = (TableRow)LayoutInflater.from(PlaceOrderActivity.this).inflate(R.layout.row, null);
			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j);
			((TextView)row.findViewById(R.id.textView1)).setText((j+1)+"");
		    ((TextView)row.findViewById(R.id.textView2)).setText(mi.getItemTitle());
		   
		    ((TextView)row.findViewById(R.id.textView4)).setText(mi.getItemPrice());
		    int price=StringHelper.nullObjectToIntegerEmpty(mi.getItemPrice());
		    int quantity=StringHelper.nullObjectToIntegerEmpty(mi.getItemQuantity());
		    total+=price*quantity;
		    ((EditText)row.findViewById(R.id.editTextQuantity)).setText(quantity+"");
		    String preptime=mi.getPrepTime();
		    try{
		    	int min=StringHelper.nullObjectToIntegerEmpty(preptime.subSequence(3, 5)) ;
		    totalTimeInMin+=min;
		    }catch(Exception e){
		    	
		    }
		    System.out.println("mi.getPrepTime() "+mi.getPrepTime());
		    ((EditText)row.findViewById(R.id.editTextQuantity)).addTextChangedListener(new TextWatcher() {
				
				public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
					// TODO Auto-generated method stub
					 reCalculateTotal();
					 toast("Text Changed");
					
				}
				
				public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
						int arg3) {
					// TODO Auto-generated method stub
					
				}
				
				public void afterTextChanged(Editable arg0) {
					// TODO Auto-generated method stub
					
				}
			});
		    tl.addView(row);
		    
		}
		
		TableRow row = (TableRow)LayoutInflater.from(PlaceOrderActivity.this).inflate(R.layout.row, null);
		
		((TextView)row.findViewById(R.id.textView1)).setText(" ");
	    ((TextView)row.findViewById(R.id.textView2)).setText("Total ");
	    ((TextView)row.findViewById(R.id.textView4)).setText(total+"");
	    ((EditText)row.findViewById(R.id.editTextQuantity)).setVisibility(EditText.INVISIBLE);
	    tl.addView(row);
	}
	
	private void reCalculateTotal() {
		TableLayout tl=(TableLayout)findViewById(R.id.tableLayout1);
		
		
		int total=0;
		int j =1;
		for (j = 1; j <tl.getChildCount()-1; j++) {
			TableRow row = (TableRow) tl.getChildAt(j);
			String q= ((EditText)row.findViewById(R.id.editTextQuantity)).getText().toString();
			int quantity=StringHelper.nullObjectToIntegerEmpty(q);
			if(quantity>0){
			
			
			String p= ((TextView)row.findViewById(R.id.textView4)).getText().toString();
			int price=StringHelper.nullObjectToIntegerEmpty(p);
			  total+=price*quantity;
			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j-1);
			mi.setItemQuantity(quantity);
			
			}else{
				toast("Please enter quantity");
			}
			
			
		}
		TableRow row = (TableRow) tl.getChildAt(j);
		 ((TextView)row.findViewById(R.id.textView4)).setText(total+"");
	}
	public void saveOrder(View v){
		
		String itemId="";
		String itemQunaity="";
		
		int total=0;
		for (int j = 0; j < RestaurantCMActivity.orders.size(); j++) {
			MenuItem mi=(MenuItem)RestaurantCMActivity.orders.get(j);
			itemId+=","+mi.getMenuId();
			int price=StringHelper.nullObjectToIntegerEmpty(mi.getItemPrice());
			int quantity=StringHelper.nullObjectToIntegerEmpty(mi.getItemQuantity());
			total+=price*quantity;
			itemQunaity+=","+quantity;
		}
		if(itemId.length()>0){
			itemId=itemId.substring(1);
		}
		if(itemQunaity.length()>0){
			itemQunaity=itemQunaity.substring(1);
		}
		
		saveOrder(itemId,itemQunaity,total,AndroidConstants.currentUser.getUserid());
		
	}
	public void saveOrder(String menuitemids,String menuitemQuantity,int totalamount,String userid) {
		HashMap param = new HashMap();
		param.put("method", "saveOrder");
		param.put("menuitemids", menuitemids);
		param.put("totalamount", totalamount);
		param.put("userid", userid);
		param.put("itemsquantity", menuitemQuantity);
		

		String data = HttpView.connectToServer(HttpView.createURL(param));
		if(data.length()>0&&data.equalsIgnoreCase("true")){
			toast("Order Saved Successfully!!! Estimated Preparation Time is "+totalTimeInMin+" Min");
			RestaurantCMActivity.orders= new ArrayList();
			
			go(RestaurantCMActivity.class);
		}else{
			toast("Unable to place order at this time!");
		}
	}

@Override
protected void onResume() {
	// TODO Auto-generated method stub
	super.onResume();
	if(AndroidConstants.currentUser==null){
		go(LoginActivity.class);
	}
}	

}