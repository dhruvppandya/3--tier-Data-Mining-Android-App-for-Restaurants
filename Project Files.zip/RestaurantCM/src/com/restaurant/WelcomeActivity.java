package com.restaurant;

import android.content.Intent;
import android.os.Bundle;

import com.util.AndroidConstants;
import com.util.HttpView;
import com.util.StringHelper;

public class WelcomeActivity extends CommonActivity {
	protected int _splashTime = 2000;
	public static String TAG = "WelcomeActivity", value = "";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcomescreen);
		android.os.StrictMode.ThreadPolicy tp = android.os.StrictMode.ThreadPolicy.LAX;
		android.os.StrictMode.setThreadPolicy(tp);
		splashTread.start();
	}

	Thread splashTread = new Thread() {
		@Override
		public void run() {
			try {
				sleep(_splashTime);

			} catch (InterruptedException e) {
				e.printStackTrace();
				// do nothing
			} finally {
				finish();

				boolean success = HttpView
						.checkConnectivityServer(
								AndroidConstants.SERVER_IP,
								StringHelper
										.nullObjectToIntegerEmpty(AndroidConstants.SERVER_PORT));
				if (success) {
					go(LoginActivity.class);
				} else {

					Intent intent = new Intent(WelcomeActivity.this,ConfigTabActivity.class);
					intent.putExtra("MESSAGE","We are unable to connect to your default server");
					startActivity(intent);
				}

			}
		}
	};
}
