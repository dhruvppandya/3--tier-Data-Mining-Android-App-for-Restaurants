package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.util.AndroidConstants;
import com.util.ExpandableListAdapter;
import com.util.HttpView;
import com.util.MenuItem;
import com.util.StringHelper;

public class SuggestionsActivity extends CommonActivity {

	ExpandableListView elv = null;
boolean fromCustomized=false;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sugeestions);
		elv = (ExpandableListView) findViewById(R.id.expandableList);
		SuggestionsActivity.menuList=getMenuList();
				fromCustomized=getIntent().getBooleanExtra("CUSTOMIZED", false);
				if(fromCustomized){
					setTitle("My Customized Menu");
					
				}else{
					setTitle("Our Suggestions");
				}
				setListAdapter();	
		

	}

	ExpandableListAdapter expListAdapter = null;

	public void setListAdapter() {

		expListAdapter = new ExpandableListAdapter(SuggestionsActivity.this,
				getGroups(),
				getSubCatagories());
		elv.setAdapter(expListAdapter);

	}


	public void onClick(View v) {
		System.out.println("View " + v.getParent());

		if (v.getParent() instanceof RelativeLayout) {
			CheckBox c = (CheckBox) v;
			if (c.isChecked()) {

				RelativeLayout rl = (RelativeLayout) v.getParent();
				System.out.println(((TextView) rl.findViewById(R.id.textView2))
						.getText());
				System.out.println(v.getTag());
				MenuItem mi = (MenuItem) v.getTag();
				orders.add(mi);
			
			}else{
				
				MenuItem mi = (MenuItem) v.getTag();
				for (int i=0;i<orders.size();i++) {
					MenuItem miter= (MenuItem) orders.get(i);
					if(miter==mi){
						orders.remove(i);
						
					}
				}
			}
		}
		System.out.println("orders Size "+orders.size());
	}

	public static ArrayList orders = new ArrayList();

	@Override
	public void onContentChanged() {
		// TODO Auto-generated method stub
		super.onContentChanged();
		toast("onContentChanged ");
	}

	public static HashMap imgMap = new HashMap();

	

	public ArrayList<HashMap> getGroups() {
		ArrayList arr = new ArrayList();
		for (int i = 1; i < 5; i++) {
			HashMap hmp=new HashMap();
			hmp.put("catagoryDesc", "Best Combos - "+i);
			arr.add(hmp);
		}
	return arr;
		
	}
	public ArrayList getSubCatagories() {
//		ArrayList arr = new ArrayList();
		SuggestionsActivity.menuList=getMenuList();
		HashMap param = new HashMap();
		param.put("method", "calculateAprioriCombinations");
		if(fromCustomized){
			param.put("userid",AndroidConstants.currentUser.getUserid());
		}
		Object o= HttpView.connect2ServerObject(HttpView.createURL(param));
		System.out.println("GOt Object From Server "+o);
		ArrayList<ArrayList<MenuItem>> arr=new ArrayList<ArrayList<MenuItem>>();
		if(o instanceof HashMap){
			HashMap hmp=(HashMap)o;
		
			for (int i = 1; i < 5; i++) {
				if(hmp.get(i)!=null){
					
					ArrayList<MenuItem> a=new ArrayList<MenuItem>();
					Object[] oarray=(Object[]) hmp.get(i);
					String[] values=(String[]) oarray[0];
					if(values!=null&&values.length>0){
					System.out.println(" "+i+" "+values+" "+values.length);
					String items=","+values[0]+",";  
				System.out.println("items "+items);
					for (int j = 0; j < SuggestionsActivity.menuList.size(); j++) {   
						HashMap record=(HashMap) SuggestionsActivity.menuList.get(j);
						String menuId=StringHelper.n2s(record.get("menuId")) ;
						System.out.println("items.indexOf(,menuId,) "+items.indexOf(","+menuId+",")+" "+menuId);
						if(items.indexOf(","+menuId+",")!=-1){
							
							String cata = StringHelper.nullObjectToStringEmpty(record
									.get("catagory"));
							String itemTitle = StringHelper.nullObjectToStringEmpty(record
									.get("itemTitle"));

							String itemDesc = StringHelper.nullObjectToStringEmpty(record
									.get("itemDesc"));
							String mid = StringHelper.nullObjectToStringEmpty(record
									.get("menuId"));
							String itemPrice = StringHelper.nullObjectToStringEmpty(record
									.get("itemPrice"));
							
							MenuItem mi = new MenuItem();
							mi.setCatagory(cata);
							mi.setItemTitle(itemTitle);
							mi.setItemDesc(itemDesc);
							mi.setItemPrice(itemPrice);
							mi.setMenuId(mid);
							String prepTime = StringHelper.nullObjectToStringEmpty(param
									.get("prepTime"));
							mi.setPrepTime(prepTime);
							mi.setItemQuantity(1);
							a.add(mi);
						}
						
					}
					}
					arr.add(a);
				}
				
			}
			
		}
		System.out.println("Got the getCatagories "
				+ arr.size());
		return arr;
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(AndroidConstants.currentUser==null){
			go(LoginActivity.class);
		}
	}
	public static final String LOG_TAG = "DomainActivity ";
	public static ArrayList menuList = new ArrayList();
	public static ArrayList catagoryList = new ArrayList();

}