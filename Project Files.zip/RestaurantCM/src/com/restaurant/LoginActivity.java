package com.restaurant;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.util.AndroidConstants;
import com.util.HttpView;
import com.util.StringHelper;
import com.util.UserAccount;

public class LoginActivity extends CommonActivity {
	EditText login;
	ArrayList data=new ArrayList();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		android.os.StrictMode.ThreadPolicy tp = android.os.StrictMode.ThreadPolicy.LAX;
		android.os.StrictMode.setThreadPolicy(tp);
		login=(EditText)findViewById(R.id.editText1);
	}
	public void fnRegister(View v) {
		go(RegisterActivity.class);
	}
	public void register(View v) {
		HashMap param = new HashMap();
		param.put("method", "checkLogin");
		param.put("customer", login.getText().toString());
		param.put("imei", getIMEI());
		data = HttpView.getArrayServer(param);
		if(data.size()>0){
			UserAccount ua= (UserAccount) data.get(0);
			
			AndroidConstants.currentUser=ua;
			toast("User Authenticated successfully!");
			go(RestaurantCMActivity.class);
		}else{
			
			toast("Invalid Customer Name!");
		}
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		boolean success = HttpView
				.checkConnectivityServer(
						AndroidConstants.SERVER_IP,
						StringHelper
								.nullObjectToIntegerEmpty(AndroidConstants.SERVER_PORT));
		if (!success) {
			go(ConfigTabActivity.class);
		}
	}
}

