package main.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.util.AprioriUtility;
import com.util.DatabaseUtility;

public class Apriori {

	public static void main(String[] args) {
//		calculateAprioriCombinations(1);
System.out.println(padRight("Apriori", 8)+"-");
	}

	public static HashMap calculateAprioriCombinations(int userId) {

		// Creating Menu Item List - list of items on which apriori algorithm
		// will be applied Start

		HashMap map = new HashMap();
		List nitems = DatabaseUtility
				.getMapList("SELECT MENUID FROM `rcm`.`menuitems` ");
		String query="SELECT menuitemids FROM `rcm`.`customerorders`";
		//where userid=7 
		if(userId!=0){
			query+="	where userid="+userId;
		}
		System.out.println(query);
		ArrayList customerorders = (ArrayList) DatabaseUtility
				.getMapList(query);
		System.out.println("The No of Orders is " + nitems);
		System.out.println("The No of Orders is " + customerorders.size()); // For Getting the
		// Minimum Support so that we can get First Set
		int minSupport; // For// Getting the Size of the List to calculate the
						// Minimum Support
		int size =customerorders.size();
		if (size % 2 == 0) {
			minSupport = (int) ((int) size * 0.2);
			System.out.println("The Minimum Support  is  " + minSupport);
		} else {
			minSupport = (int) ((int) size * 0.2);
			System.out.println("The Minimum Support  is  " + minSupport);
		}
		
		System.out.println("The min support is "+minSupport);
		Object[] list1 = AprioriUtility.firstSet(nitems, minSupport,customerorders);
		System.out.println("The List 1 is " + list1.length);
		map.put(1, list1);
		Object[] list2 = AprioriUtility.secondSet((Object[]) list1[0], minSupport,customerorders);
		map.put(2, list2);
		System.out.println("The List 2 is " + list2.length);
		Object[] list3 = AprioriUtility.thirdSet((Object[]) list2[0], minSupport,customerorders);
		map.put(3, list3);
		System.out.println("The List 3 is " + list3.length);
		Object[] list4 = AprioriUtility.fourthSet((Object[]) list3[0], minSupport,customerorders);
		System.out.println("The List 4 is " + list4.length);
		map.put(4, list4);

		
		
		// For checking whether the Particular combination contains the
		// required combination or not

//		String support = AprioriUtility.getRequiredSet(list3, minSupport);
//		System.out.println(support);
		map.put("SUPPORT", minSupport);

		// For Finding the Customer List with more than specified Amount Bill
		// Starts
//		int amount = 400;
//		List branchOpen = AprioriUtility.getBranchOpening(amount);
//		System.out.println("The List of Address for branch Opening are "
//				+ branchOpen);
//		// For Finding the Customer List with more than specified Amount Bill
//		// Ends
//
//		// For Getting the Waiting time between Order and Delivery Starts
//		int i = 0;
//		List waitingTime = AprioriUtility.getWaitingTime(i);
//		System.out.println("The Waiting Time is " + waitingTime);

		/*
		 * int i=3; if(i==1){ List list1 = AprioriUtility.firstSet(nitems,
		 * minSupport); if(list1.isEmpty()){
		 * System.out.println("The is no best possible combination "); } else{
		 * System.out.println("The First Set is "+list1); } }else if(i==2){ List
		 * list1 = AprioriUtility.firstSet(nitems, minSupport);
		 * if(list1.isEmpty()){
		 * System.out.println("The is no best possible combination "); } else{
		 * System.out.println("The First Set is "+list1); } List
		 * list2=AprioriUtility.secondSet(list1, minSupport);
		 * if(list2.isEmpty()){
		 * System.out.println("The best possible combination is "+list1); }
		 * else{ System.out.println("The Second Set is "+list2); } }else
		 * if(i==3){ List list1 = AprioriUtility.firstSet(nitems, minSupport);
		 * if(list1.isEmpty()){
		 * System.out.println("The is no best possible combination "); } else{
		 * System.out.println("The First Set is "+list1); } List
		 * list2=AprioriUtility.secondSet(list1, minSupport);
		 * if(list2.isEmpty()){
		 * System.out.println("The best possible combination is "+list1); }
		 * else{ System.out.println("The Second Set is "+list2); } List
		 * list3=AprioriUtility.thirdSet(list2, minSupport);
		 * 
		 * if(list3.isEmpty()){
		 * System.out.println("The best possible combination is "+list2); }
		 * else{ System.out.println("The Third Set is "+list3); } }
		 */
		return map;
	}
	
	public static String padRight(String s, int n) {
	     return String.format("%1$-" + n + "s", s);  
	}

	public static String padLeft(String s, int n) {
	    return String.format("%1$" + n + "s", s);  
	}
}
