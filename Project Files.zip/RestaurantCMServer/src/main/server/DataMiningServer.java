package main.server;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.util.AprioriUtility;
import com.util.ConnectionManager;
import com.util.StringHelper;

public class DataMiningServer {
	public static void main(String[] args) throws IOException {
		InetSocketAddress addr = new InetSocketAddress(9898);
		HttpServer server = HttpServer.create(addr, 0);
		server.createContext("/", new MyHandler());
		server.setExecutor(Executors.newCachedThreadPool());
		server.start();
		System.out.println("Server is listening on port 9898");

		// Constants.MY_HOST_NAME =
		// ExecuteDOSCommand.getCommandOutput("hostname",
		// 0).toString();
	}
}

class MyHandler implements HttpHandler {
	public void handle(HttpExchange exchange) throws IOException {

		try {
			boolean skipWriting = false;
			String requestMethod = exchange.getRequestMethod();

			String uri = exchange.getRequestURI().getQuery();
			System.out.println("URI " + uri);
			HashMap parameters = new HashMap();
			if (uri != null) {
				String tokens[] = uri.split("&");
				System.out.println("tokens " + tokens.length);
				for (String keyvalue : tokens) {
					String tok[] = keyvalue.split("=");
					String key = "", value = "";
					if (tok.length > 0)
						key = tok[0];
					if (tok.length > 1)
						value = tok[1];
					// System.out.println("key "+key+"  "+value);
					parameters.put(key, URLDecoder.decode(value));
				}
			}

			// if (requestMethod.equalsIgnoreCase("GET")) {
			Headers responseHeaders = exchange.getResponseHeaders();
			responseHeaders.set("Content-Type", "text/plain");
			exchange.sendResponseHeaders(200, 0);

			OutputStream responseBody = exchange.getResponseBody();
			Headers requestHeaders = exchange.getRequestHeaders();

			System.out.println("Method " + parameters.get("method"));
			System.out.println("m in method");
			StringBuffer sb = new StringBuffer();
			if (parameters.get("method") != null) {
				String method = parameters.get("method").toString();
				if (method.equalsIgnoreCase("checkLogin")) {

					String cname = StringHelper
							.nullObjectToStringEmpty(parameters.get("customer"));
					String imei= StringHelper
							.nullObjectToStringEmpty(parameters.get("imei"));
					ArrayList list = ConnectionManager.checkCustomer(cname,imei);
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(list);
					os.flush();
					os.close();
					skipWriting = true;
				} else if (method.equalsIgnoreCase("registerCustomer")) {

					boolean success = ConnectionManager
							.registerCustomer(parameters);
					sb.append(success);
				}else if (method.equalsIgnoreCase("updateOrderStatus")) {
					String orderId= StringHelper
							.nullObjectToStringEmpty(parameters.get("orderId"));
					String status= StringHelper
							.nullObjectToStringEmpty(parameters.get("status"));
					
					ConnectionManager
							.updateOrder(status, orderId);
					sb.append("");
				} 
				
				
				else if (method.equalsIgnoreCase("menu")) {
					List list = null;
					list = ConnectionManager.getMenuItems();
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(list);
					os.flush();
					os.close();
					skipWriting = true;
				}else if (method.equalsIgnoreCase("saveOrder")) {
					boolean success = ConnectionManager.saveOrder(parameters);
					sb.append(success);
				}
				else if (method.equalsIgnoreCase("calculateAprioriCombinations")) {
					int userid= StringHelper.n2i(parameters.get("userid"));
					HashMap success =Apriori.calculateAprioriCombinations(userid);
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(success);
					os.flush();
					os.close();
					skipWriting = true;
				}	
				else if (method.equalsIgnoreCase("getTodaysPendingOrder")) {
					int status=0;
					List list = null;
					
					int userId= StringHelper.n2i(parameters.get("userId"));
					list =ConnectionManager.getTodaysKitchenOrders(status,userId);
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(list);
					os.flush();
					os.close();
					skipWriting = true;
				}
				else if (method.equalsIgnoreCase("catagories")) {
					List list = null;
					list = ConnectionManager.getCatagories();
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(list);
					os.flush();
					os.close();
					skipWriting = true;
				}
				else if (method.equalsIgnoreCase("getBranchOpening")) {
					int amount= StringHelper.n2i(parameters.get("amount"));
					List success =AprioriUtility.getBranchOpening(amount);
					ObjectOutputStream os = new ObjectOutputStream(responseBody);
					os.writeObject(success);
					os.flush();
					os.close();
					skipWriting = true;
				}

			}
			if (!skipWriting) {
				System.out.println("after method");
				System.out.println(sb.toString());

				responseBody.write(sb.toString().getBytes());
				responseBody.flush();
				responseBody.close();
			}
			System.out
					.print("..........Completing Response from here ..............");

			// }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}