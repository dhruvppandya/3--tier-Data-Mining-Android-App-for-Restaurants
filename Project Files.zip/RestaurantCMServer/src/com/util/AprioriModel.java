package com.util;

public class AprioriModel {
	String orderid;
	String menuitemids;
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getMenuitemids() {
		return menuitemids;
	}
	public void setMenuitemids(String menuitemids) {
		this.menuitemids = menuitemids;
	}
}
