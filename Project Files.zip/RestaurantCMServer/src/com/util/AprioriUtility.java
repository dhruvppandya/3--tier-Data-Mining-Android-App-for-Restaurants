package com.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.sun.org.apache.xpath.internal.operations.Minus;

public class AprioriUtility {
	public static Object[] firstSet(List nitems, int minSupport,List customerOrders) {
		System.out.println("The customer order list is"+customerOrders+" and Menu Items are "+nitems);
		String[] menuItems = new String[nitems.size()];
		for (int i = 0; i < nitems.size(); i++) {
			HashMap hmp = (HashMap) nitems.get(i);
			String menuId = StringHelper.n2s(hmp.get("MENUID"));
			menuItems[i] = menuId;
		}
		// Creating Menu Item List - list of items on which apriori algorithm
		// will be applied End

		// Now Creating Menu Item List - list from database orders will be
		// checked and occurencecs will be recorded Starts
		HashMap frequenceMenuItems = new HashMap();
		for (int i = 0; i < customerOrders.size(); i++) {
			HashMap hmp = (HashMap) customerOrders.get(i);
			String menuitemids = StringHelper.n2s(hmp.get("menuitemids"));
			String orderItems[] = menuitemids.split(",");
			for (int j = 0; j < orderItems.length; j++) {
				for (int j2 = 0; j2 < menuItems.length; j2++) {
					String string = StringHelper.n2s(orderItems[j]);
					if (string.length() > 0) {
						if(string.contains(menuItems[j2])){
							int f=StringHelper.n2i(frequenceMenuItems.get(string));
							f++;
							frequenceMenuItems.put(string, f);
						}
//						String[] arr = string.split(",");
//						for (int k = 0; k < arr.length; k++) {
//							if (arr[k].equalsIgnoreCase(menuItems[j2])) {
//								int f = StringHelper.n2i(frequenceMenuItems
//										.get(string));
//								f++;
//								frequenceMenuItems.put(string, f);
//							}
//						}

					}
				}
			}
		}
//		Set keys = frequenceMenuItems.keySet();
//
//		// Now Creating Menu Item List - list from database orders will be
//		// checked and occurencecs will be recorded Ends
//
//		// Now the Menu Items with the Occurences less then Minimum Support is
//		// removed Starts
//		// List Which will contain the new Items with Required Minimum Support
//		List<String> newList = new ArrayList<String>();
//		try {
//			for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
//				String key = (String) iterator.next();
//				int value = StringHelper.n2i(frequenceMenuItems.get(key) + "");
//				if (value >= minSupport) {
//					newList.add(key);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		// Now the Menu Items with the Occurences less then Minimum Support is
//		// removed Ends

		return getOrderedList(frequenceMenuItems, minSupport);
	}

	public static Object[] secondSet(Object[] newList1, int minSupport,List nitems) {

		// It sorts the given List in Ascending Order
		// Step 1 type cast String Array List into Integer Array List Starts
		List<Integer> newList2 = new ArrayList<Integer>();
		

//		Collections.sort(newList2);
		String[] tempArray = Arrays.asList(newList1).toArray(new String[newList1.length]);
		
		for (int i=0;i<tempArray.length;i++) {
		newList2.add(StringHelper.n2i(tempArray[i]));
	}
		Collections.sort(newList2);
		// Step 1 type cast String Array List into Integer Array List Ends

		// Step 2 type cast Integer Array List into String Array List Starts
		
		List<String> newList = new ArrayList<String>(newList2.size());
		for (Iterator iterator1 = newList2.iterator(); iterator1.hasNext();) {
			newList.add(StringHelper.n2s(iterator1.next()));
		}
	
		
		
		// Step 2 type cast Integer Array List into String Array List Ends

		// Set 1 will be made using this List Items
		// Calculating the Size of the newly formed Array in Set 1 Starts
		int len = 1;
		for (int i = 2; i < newList.size(); i++) {
			len = len + i;
		}
		// Calculating the Size of the newly formed Array in Set 1 Ends
		// Now the Set 1 Starts
		String[] newSet1 = new String[len];
		String[] string2 = new String[newList.size()];

		// Getting the elements of the List in the String Array Starts
		for (Iterator iterator = newList.iterator(); iterator.hasNext();) {
			for (int j = 0; j < newList.size(); j++) {
				string2[j] = StringHelper.nullObjectToStringEmpty(iterator
						.next());
			}
		}
		// Getting the elements of the List in the String Array Ends

		// Forming the New Set of Combination to compare with the Menu's in the
		// Orders Starts
		int inc = 0;
		for (int i = 0; i < string2.length; i++) {
			for (int j = i + 1; j < string2.length; j++) {
				newSet1[inc] = string2[i] + "," + string2[j];
				inc++;
			}
		}
		// Forming the New Set of Combination to compare with the Menu's in the
		// Orders Ends

		// Here the Newly Formed String Array is Displayed Starts
//		System.out.println("the Elements of the newly formed array  are");
//		for (int i = 0; i < newSet1.length; i++) {
//			System.out.println(newSet1[i]);
//		}
		// Here the Newly Formed String Array is Displayed Ends

		// Now we compare the newly formed String Array with the MenuOrder in
		// Orders Starts
		// Here the All the Menu's from the Orders is Copied in List i.e. nitems
		// Starts
//		List nitems = DatabaseUtility
//				.getMapList("SELECT menuitemids FROM `rcm`.`customerorders`");
		
		// Here the All the Menu's from the Orders is Copied in List i.e. nitems
		// Ends

		// The Checking of the Presence of the Combination in the List Starts
		HashMap<String,Integer> frequenceMenuItems1 = new HashMap<String, Integer>();
		try {
			for (int j = 0; j < newSet1.length; j++) {
				int occur = 0;
				String str2 = "";
				for (int i = 0; i < nitems.size(); i++) {
					String str1 = StringHelper.nullObjectToStringEmpty(nitems
							.get(i));
					if (str1.contains(newSet1[j])) {
						str2 = newSet1[j];
						occur++;
					}
				}
				if (occur > 0) {
					frequenceMenuItems1.put(str2, occur);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		// The Checking of the Presence of the Combination in the List Ends

		// After Getting the New Set with their presence in the Menu's of Orders

		// Now the Checking the Occurence of the New Set with the MinSupport
		// Starts
		// Here Golden Rule 1 is used and Combination with less than MinSupport
		// is Removed

		return getOrderedList(frequenceMenuItems1, minSupport);
	}

	public static Object[] getOrderedList(HashMap frequenceMenuItems1,
			int minSupport) {
		List<String> returnNewList = new ArrayList<String>();
		Set keys1 = frequenceMenuItems1.keySet();
		HashMap frequenceMenuItemsReverse = new HashMap();
		for (Iterator iterator = keys1.iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			int value = StringHelper.n2i(frequenceMenuItems1.get(key) + "");
			System.out.println("The key is "+key+" and value is "+value);
			if (value >= minSupport) {
				frequenceMenuItemsReverse.put(key, value);
			}
			
		}
		Set<String> keys=frequenceMenuItemsReverse.keySet();
		String[] keysArray =new String[keys.size()];
		int i = -1;
		for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			keysArray[++i]=string;
			
		}
		
	
		Collection<Integer> values=frequenceMenuItemsReverse.values();
		Integer[] valuesArray = new Integer[values.size()];
		int j = -1;
		for (Iterator iterator = values.iterator(); iterator.hasNext();) {
			int string = StringHelper.n2i(iterator.next()) ;
			valuesArray[++j]=string;
			
		}
//		Integer[] valuesArray = Arrays.asList(values).toArray(new Integer[values.size()]);
		
		
		 for( i=0; i<valuesArray.length -1; i++){
	         
	            //Inner loop to perform comparision and swapping between adjacent numbers
	            //After each iteration one index from last is sorted
	            for(j= 1; j<valuesArray.length -i; j++){
	             
	                //If current number is greater than swap those two
	                if(valuesArray[j-1] < valuesArray[j]){
	                    int temp = valuesArray[j];
	                    valuesArray[j] = valuesArray[j-1];
	                    valuesArray[j-1] = temp;
	                    
	                    String temp1 = keysArray[j];
	                    keysArray[j] = keysArray[j-1];
	                    keysArray[j-1] = temp1;
	                    
	                }
	            }
	        }
		
		 
//		List<Integer> mapValues = new ArrayList(
//				frequenceMenuItemsReverse.keySet());
//		Collections.sort(mapValues, Collections.reverseOrder());

//		frequenceMenuItems1.clear();
//		ArrayList<String> keys = new ArrayList<String>();
//		for (Iterator iterator = mapValues.iterator(); iterator.hasNext();) {
//			String s = StringHelper.n2s(iterator.next());
//			Integer value = Integer.parseInt(s);
//			String key = StringHelper.n2s(frequenceMenuItemsReverse.get(value));
//			keys.add(key);
//			System.out.println("key "+key+" "+value);
//		}
		Object[] list = new Object[2];
		list[0] = keysArray; // ELements
		list[1] = valuesArray; // Count
		System.out.println("The " + Arrays.toString(keysArray)+ " is  and value is " + Arrays.toString(valuesArray));
		return list;
	}

	public static Object[] thirdSet(Object[] newList2, int minSupport,List nitems) {

		// Elements of the List is Copied in the String Starts
		String temp = "";
		// for (Iterator iterator = newList2.iterator(); iterator.hasNext();) {
		// temp += "#" + iterator.next();
		// }
		// // Elements of the List is Copied in the String Ends
		// System.out.println(temp);

		// Here the String Contents are Split in the String Array Starts
		// temp.trim();

		// Object[] tempArray = (Object[]) newList2;
		String[] tempArray = Arrays.asList(newList2).toArray(
				new String[newList2.length]);
		// Here the String Contents are Split in the String Array Ends

		// According the Golden Rule 2 of the Apriori Algorithm
		// Combination's First letter if matches then those
		// Combination are Concatenated
		// Eg : 1,2 and 1,3 then 1,2,3
		// Grouping Starts
		ArrayList<String> tempStr = new ArrayList<String>();
		for (int i = 0; i < tempArray.length; i++) {
			int count = 0;
			for (int j = 0; j < tempArray.length; j++) {
				if (tempArray[j].split(",")[0].equalsIgnoreCase(tempArray[i]
						.split(",")[0])) {
					count++;
					if (count > 1) {
						if (tempArray[j].split(",")[1]
								.equalsIgnoreCase(tempArray[i].split(",")[1])) {

						} else {
							tempStr.add(tempArray[i] + ","
									+ tempArray[j].split(",")[1]);
						}

					}
				}
			}

		}
		// Grouping Ends

	

		// Now the New Combinations are checked with Menu's in Order
		// There Occurences are Stored
		// Checking Procedure Starts
		HashMap frequenceMenuItems2 = new HashMap();
//		List nitems = DatabaseUtility
//				.getMapList("SELECT menuitemids FROM `rcm`.`customerorders`");
		for (int j = 0; j < tempStr.size(); j++) {
			int occur = 0;
			String str2 = "";
			for (int i = 0; i < nitems.size(); i++) {

				String str1 = StringHelper.nullObjectToStringEmpty(nitems
						.get(i));
				String str3 = StringHelper.nullObjectToStringEmpty(tempStr
						.get(j));
				boolean b = str1.contains(str3);

				if (b) {

					str2 = StringHelper.nullObjectToStringEmpty(str3);
					occur++;

				}
			}
			if (occur > 0) {
				
				frequenceMenuItems2.put(str2, occur);
			}
		}
		// Checking Procedure Ends

		// Now According to Golden Rule 1 the
		// Combination with the less Occurences then Minimum Support
		// are Removed
		// Checking Procedure Starts

			return getOrderedList(frequenceMenuItems2, minSupport);
	
		// Checking Procedure Ends
	}

	public static Object[] fourthSet(Object[] newList3, int minSupport,List nitems) {

		// Elements of the List is Copied in the String
		// Copying Procedure Starts
		String[] tempArray = Arrays.asList(newList3).toArray(
				new String[newList3.length]);
		// Splitting of String Ends

		// Now According to the Golden Rule 3
		// The New Combination if prepared if the
		// First two values are same and Third one
		// is different
		// Eg : 1,2,3 and 1,2,4 then 1,2,3,4

		// Combination Creation Starts
		ArrayList<String> tempStr = new ArrayList<String>();
		for (int i = 0; i < tempArray.length; i++) {
			int count = 0;
			for (int j = 0; j < tempArray.length; j++) {

				if (tempArray[j].split(",")[0].equalsIgnoreCase(tempArray[i]
						.split(",")[0])) {
					count++;
					if (count > 1) {
						if (tempArray[j].split(",")[1]
								.equalsIgnoreCase(tempArray[i].split(",")[1])) {
							count++;
							if (count > 2) {
								if (tempArray[j].split(",")[2]
										.equalsIgnoreCase(tempArray[i]
												.split(",")[2])) {

								} else {
									tempStr.add(tempArray[i] + ","
											+ tempArray[j].split(",")[2]);
								}
							}
						}
					}
				}
			}
		}
		// Combination Creation Ends

		System.out.println(tempStr);

		// Now the contents of the List is checked against the Menus Items
		// in Orders and their Occurence's is Stored
		// Checking Procedure Starts
		HashMap frequenceMenuItems2 = new HashMap();
//		List nitems = DatabaseUtility
//				.getMapList("SELECT menuitemids FROM `rcm`.`customerorders`");
		for (int j = 0; j < tempStr.size(); j++) {
			int occur = 0;
			String str2 = "";
			for (int i = 0; i < nitems.size(); i++) {

				String str1 = StringHelper.nullObjectToStringEmpty(nitems
						.get(i));
				String str3 = StringHelper.nullObjectToStringEmpty(tempStr
						.get(j));
				boolean b = str1.contains(str3);

				if (b) {

					str2 = StringHelper.nullObjectToStringEmpty(tempStr);
					occur++;

				}
			}
			if (occur > 0) {
				frequenceMenuItems2.put(str2, occur);
			}
		}
		// Checking Procedure Ends

		// Now the According to the Golden Rule 1
		// Combination less then the Minimum Support are Removed
		// Checking Procedure Starts

			return getOrderedList(frequenceMenuItems2, minSupport);
		
		// Checking Procedure Ends
	}

	public static String getRequiredSet(List list, int minSupport) {
		// Here Occurence of Elements or Combination in List
		// are stored
		// Calculating the Occurences Starts
		HashMap frequenceMenuItems2 = new HashMap();
		List nitems = DatabaseUtility
				.getMapList("SELECT menuitemids FROM `rcm`.`customerorders`");
		for (int j = 0; j < list.size(); j++) {
			int occur = 0;
			String str2 = "";
			for (int i = 0; i < nitems.size(); i++) {
				String str1 = StringHelper.nullObjectToStringEmpty(nitems
						.get(i));
				String str3 = StringHelper.nullObjectToStringEmpty(list.get(j));
				boolean b = str1.contains(str3);
				if (b) {
					str2 = StringHelper.nullObjectToStringEmpty(list.get(j));
					occur++;

				}
			}
			if (occur > 0) {
				;
				frequenceMenuItems2.put(str2, occur);
			}
		}
		// Calculating the Occurences Ends

		// Now According to the Golden Rule
		// Occurence is checked against the Minimum Support
		// It returns the Occurence
		// Checking Starts
		List<String> newList = new ArrayList<String>();
		Set keys2 = frequenceMenuItems2.keySet();
		String returnString = "The Combination has no Minimum Support";
		for (Iterator iterator = keys2.iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			int value = StringHelper.n2i(frequenceMenuItems2.get(key) + "");
			System.out.println("The key is " + key + " and value is " + value);
			if (value >= minSupport) {
				returnString = "The Combination has the Minimum Support";
			}
		}
		return returnString;
		// Checking Ends
	}

	// Function for Branch Opening Suggestion
	/*
	 * 
	 * select * from (SELECT u.address,count(c.userid) as cnt FROM
	 * rcm.customerorders c,rcm.useraccounts u where c.totalamount > 300 and
	 * c.userid =u.userid group by u.address order by c.userid ) A order by
	 * A.cnt desc
	 */
	public static List getBranchOpening(int amount) {
		// Get the Address List with more than the Specified Amount Starts
		List addrList = DatabaseUtility
				.getMapList("select A.address,A.cnt from (SELECT u.address,count(c.userid) as cnt FROM rcm.customerorders c,rcm.useraccounts u  where  c.totalamount > "+amount+" and c.userid =u.userid group by u.address order by c.userid ) A,Branches B where A.address != b.branch order by A.address desc limit 1");
		System.out.println("The Customer List is " + addrList);
		return addrList;
		// Get the Address List with more than the Specified Amount Ends
	}

	public static List getWaitingTime(int diff) {
		String query = "SELECT orderid,userid,menuitemids,totalamount, TIMEDIFF(TIME(`delivertime`),TIME(`orderdate`)) as wait, orderdate FROM `customerorders` where DATE(`orderdate`) = CURDATE() - '"
				+ diff
				+ "' order by TIMEDIFF(TIME(`delivertime`),TIME(`orderdate`)) DESC";
		List returnList = DatabaseUtility.getMapList(query);
		return returnList;
	}
}
