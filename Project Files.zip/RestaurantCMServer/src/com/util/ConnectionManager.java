
package com.util;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


public class ConnectionManager extends DatabaseUtility {


	public static void main(String args[]) throws Exception {
		Connection conn = getDBConnection();
		conn.close();
		getTodaysKitchenOrders(0,0);
		int day=new Date().getDate();
		int month=new Date().getMonth();
		month+=1;
		int i=new Date().getYear();
		i=i+1900;
		System.out.println(day+" "+month+" "+ i);
	}
	public static boolean isIMEIExists(String imei) {
		String query="SELECT imei, ipaddress, domainId, displayName, lac, cellId, lat, longitude, activeFlag, udate, userid FROM useraccount where imei = '"+imei+"'";
		System.out.println("query "+query);
	
		List list=getMapList(query);
		if(list.size()>0){
			return true;
		}else{
			return false;
		}   
	}
	public static  ArrayList checkCustomer(String customer,String imei){
		boolean success=false;
		String query="select * from  useraccounts  where phoneno LIKE '"+customer+"'";
		ArrayList list=(ArrayList) getBeanList(UserAccount.class, query);
		System.out.println("list "+list.size());
		if(list.size()>0){
			UserAccount ua= (UserAccount) list.get(0);
			query="update useraccounts set imei='"+imei+"' where phoneno  LIKE '"+customer+"'";
			executeUpdate(query, new Object[]{});
		}
		
		return list;
	}
	
	
	
	public static  boolean saveOrder(HashMap param){
		boolean success=false;
		String query="insert into customerorders (userid, menuitemids, totalamount,menuitemquantity,delivertime) values (?,?,?,?,CURRENT_TIMESTAMP())";
		String userid=StringHelper.nullObjectToStringEmpty(param.get("userid"));
		String menuitemids=StringHelper.nullObjectToStringEmpty(param.get("menuitemids"));
		String totalamount=StringHelper.nullObjectToStringEmpty(param.get("totalamount"));
		String itemsquantity=StringHelper.nullObjectToStringEmpty(param.get("itemsquantity"));
		int i=executeUpdate(query, new Object[]{userid,menuitemids,totalamount,itemsquantity});
		if(i>0){
			success=true;
		}
		return success;
	}
	public static  boolean registerCustomer(HashMap param){
		boolean success=false;
		String query="insert into useraccounts  (cname, caddress, phoneno, emailid,  dob, doaniv, roleid, address,imei) values (?,?,?,?,?,?,?,?,?)";
		
		String cname=StringHelper.nullObjectToStringEmpty(param.get("cname"));
		String caddress=StringHelper.nullObjectToStringEmpty(param.get("caddress"));
		String phoneno=StringHelper.nullObjectToStringEmpty(param.get("phoneno"));
		String emailid=StringHelper.nullObjectToStringEmpty(param.get("emailid"));
		String dob=StringHelper.nullObjectToStringEmpty(param.get("dob"));
		String doaniv=StringHelper.nullObjectToStringEmpty(param.get("doa"));
		String imei=StringHelper.nullObjectToStringEmpty(param.get("imei"));
		int roleId=1;
		String address=StringHelper.nullObjectToStringEmpty(param.get("caddress"));
		
		int i=executeUpdate(query, new Object[]{cname,caddress,phoneno,emailid,dob,doaniv,roleId,address,imei});
		if(i>0){
			success=true;
		}
		return success;
	}
	
	public static List getMenuItems() {
		
		String query="SELECT * FROM menuitems ";
		List list=getMapList(query);
		return list;
		
	}
	public static void updateOrder(String status,String orderId) {
		
		String query="update customerorders set orderstatus="+status+",delivertime=CURRENT_TIMESTAMP where orderid="+orderId;
		executeUpdate(query, new Object[]{});
			}

	
public static List getCatagories() {
		
		String query="SELECT * FROM catagories ";
		List list=getMapList(query);
		return list;
		
	}
//for getting the orders and menuitems
public static List getList(){
	String SELECT_ORDERID_MENUITEM = "SELECT orderid,menuitemids FROM `rcm`.`customerorders`";
	List list = DatabaseUtility.getBeanList(AprioriModel.class, SELECT_ORDERID_MENUITEM );
	System.out.println("The Size of List is "+list.size());
	return list;
}	
public static List getTodaysKitchenOrders(int status,int userId) {
	int day=new Date().getDate();
//	day=3;
	int month=new Date().getMonth();
	month+=1;
//	month=3;
	int year=new Date().getYear();
	year=year+1900;
	String query="";
	if(userId!=0){
		query="Select * from (SELECT c.*,u.imei,date_format(c.orderdate, '%h:%k:%s') as tm FROM customerorders c,useraccounts u where u.userid=c.userid and c.userid="+userId+" and c.orderdate >= TIMESTAMP('"+year+"-"+month+"-"+day+"') ) A left outer join restrotable r on A.imei=r.imei";
	}else{
		query="Select * from (SELECT c.*,u.imei,date_format(c.orderdate, '%h:%k:%s') as tm FROM customerorders c,useraccounts u where u.userid=c.userid and c.orderdate >= TIMESTAMP('"+year+"-"+month+"-"+day+"') and c.orderstatus="+status+") A left outer join restrotable r on A.imei=r.imei";
	}
	
	
	System.out.println(query);
	List list=getMapList(query);
	return list;
	
}

}
