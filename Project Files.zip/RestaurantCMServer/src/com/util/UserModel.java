package com.util;

public class UserModel {
	int userid;
	String cname;
	String caddress;
	String phoneno;
	String emailid;
	String dob;
	String doaniv;
	int roleid;	
	String address;
}
