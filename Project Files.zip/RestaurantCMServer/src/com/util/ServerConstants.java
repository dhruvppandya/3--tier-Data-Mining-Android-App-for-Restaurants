/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.util;

/**
 *
 * */
public class ServerConstants {



    public static String MOBILE_IP_ADDRESS="";
    public static String MY_HOST_NAME="";
    public static String lookback_self="127.0.0.1"; 
    public static final int ANDROID_MESSAGE_LISTENER = 4223;

    public static final float FRIEND_NOTIFICATION_KM_RANGE= 2f;
    
    // Queries
    
    public static String SELECT_NO_ORDER="SELECT MENUID FROM `rcm`.`menuitems`";
    
    
    
}
