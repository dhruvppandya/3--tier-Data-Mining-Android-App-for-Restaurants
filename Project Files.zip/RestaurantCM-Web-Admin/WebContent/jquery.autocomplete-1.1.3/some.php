<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
echo 'GET ';
print_r($_GET);
echo 'POST ';
print_r($_POST);
?>
