package com.util;

public class ServerConstants {
	public static String APP_TITLE="Improvised Restaurant Chain Management";
	public static String APP_SLOGAN="Feel Like Home";

	public static String lookback_self = "127.0.0.1";
	
	// Page Path
	public static final String HOME_PAGE = "pages/home.jsp";
	public static final String LOGIN_PAGE = "pages/page.jsp";

	// Queries
	public static final String CATEGORY_LIST = "SELECT * FROM `rcm`.`catagories`";
	public static final String MENU_LIST = "SELECT menuId, itemTitle, itemDesc, itemPrice, prepTime, catagoryDesc  FROM `rcm`.`menuitems` m,rcm.catagories c where m.catagory = c.catagoryId; ";
	
	public static String db_driver="com.mysql.jdbc.Driver";
	public static String db_user="root";
	public static String db_pwd="";
	public static String db_url="jdbc:mysql://localhost/rcm";
}
