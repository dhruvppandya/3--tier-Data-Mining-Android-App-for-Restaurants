package com.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class StringEncrypter {

	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	public static final String DES_ENCRYPTION_SCHEME = "DES";
	public static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";
	private KeySpec keySpec;
	private SecretKeyFactory keyFactory;
	private Cipher cipher;

	private static final String UNICODE_FORMAT = "UTF8";

	public StringEncrypter(String encryptionScheme) {
		this(encryptionScheme, DEFAULT_ENCRYPTION_KEY);
	}

	public StringEncrypter(String encryptionScheme, String encryptionKey) {

		if (encryptionKey == null)
			System.out.println("ERROR :-   encryption key was null ");
		if (encryptionKey.trim().length() < 24)
			System.out
					.println("ERROR :-   encryption key was less than 24 characters ");

		try {
			byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);

			if (encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME)) {
				keySpec = new DESedeKeySpec(keyAsBytes);
			} else if (encryptionScheme.equals(DES_ENCRYPTION_SCHEME)) {
				keySpec = new DESKeySpec(keyAsBytes);
			} else {
				throw new IllegalArgumentException(
						"Encryption scheme not supported: " + encryptionScheme);
			}

			keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
			cipher = Cipher.getInstance(encryptionScheme);

		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}

	}

	public String encrypt(String unencryptedString) {
		if (unencryptedString != null || unencryptedString.length() > 0) {

			try {
				SecretKey key = keyFactory.generateSecret(keySpec);
				cipher.init(Cipher.ENCRYPT_MODE, key);
				byte[] cleartext = unencryptedString.getBytes(UNICODE_FORMAT);
				byte[] ciphertext = cipher.doFinal(cleartext);

				BASE64Encoder base64encoder = new BASE64Encoder();
				return base64encoder.encode(ciphertext);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	public String decrypt(String encryptedString) {
		if (encryptedString != null || encryptedString.length() > 0) {

			try {
				SecretKey key = keyFactory.generateSecret(keySpec);
				cipher.init(Cipher.DECRYPT_MODE, key);
				BASE64Decoder base64decoder = new BASE64Decoder();
				byte[] cleartext = base64decoder.decodeBuffer(encryptedString);
				byte[] ciphertext = cipher.doFinal(cleartext);

				return bytes2String(ciphertext);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	private static String bytes2String(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}

	public static class EncryptionException extends Exception {
		public EncryptionException(Throwable t) {
			super(t);
		}
	}
	
	public static void main(String[] args) {
		
		
		String stringToBeEncrypted = "I am IBS!";
		System.out.println("String To Be Encrypted = "+stringToBeEncrypted);
		String s = new StringEncrypter("DES").encrypt(stringToBeEncrypted);
		String ds = new StringEncrypter("DES").decrypt(s);
		System.out.println("Decrypted String = "+ds);
		
	}
}