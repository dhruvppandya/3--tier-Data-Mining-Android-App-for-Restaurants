/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.util;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import sun.awt.windows.ThemeReader;
import java.io.*;
import java.util.zip.*;

public class ConnectionManager extends DatabaseUtility {

	public static void main(String[] args) {
		getDBConnection();
	}

	public static int index = 0;
	public static int index1 = 0;

	public static boolean fileUpload() {
		boolean success = false;

		return success;
	}

	public static String getUsers(String uid) {
		String qu = "SELECT * FROM `cloud`.`useraccount` where userId != '"
				+ uid + "' ";
		return getDropDownList(qu);
	}
	
	public static String getCategory() {
		String qu = "SELECT * FROM `rcm`.`catagories`";
		return getDropDownList(qu);
	}

	public static String getDropDownList(String query) {
		String ret = "";
		System.out.println(query);
		List list = DatabaseUtility.getBeanList(CategoryModel.class, query);

		for (int i = 0; list.size() > 0 && i < list.size(); i++) {
			CategoryModel um = (CategoryModel) list.get(i);
			ret += "<OPTION value='" + um.getCatagoryId() + "'>" + um.catagoryDesc
					+ "</OPTION>";
		}
		System.out.println("ret  " + ret);
		return ret;
	}

	public static CategoryModel getCategoryDetails(String id ){
			String sql = "SELECT * FROM `rcm`.`catagories` WHERE catagoryId = '"+id+"' ";
			List list = DatabaseUtility.getBeanList(CategoryModel.class, sql);
			CategoryModel cm = null;
			if (list.size() > 0) {
				cm = (CategoryModel) list.get(0);
			}
			return cm;
	}

	public static MenuModel getMenuDetails(String id ){
		String sql = "SELECT menuId, itemTitle, itemDesc, itemPrice, catagoryDesc,prepTime FROM `rcm`.`menuitems` m,`rcm`.`catagories` c WHERE menuId = '"+id+"' and m.catagory = c.catagoryId;";
		List list = DatabaseUtility.getBeanList(MenuModel.class, sql);
		MenuModel cm = null;
		if (list.size() > 0) {
			cm = (MenuModel) list.get(0);
		}
		return cm;
	}
	public static String getUserId(String fileId) throws SQLException {
		String arr = "";
		String sql = " SELECT `userId`,`fileName` FROM `cloud`.`filedata` where `fileId` = '"
				+ fileId + "'";
		Connection con = getDBConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			arr = rs.getString("userId");
			arr += "@" + rs.getString("fileName");
		}
		System.out.println("The array in query is " + arr);
		return arr;

	}

	public static String getUserIdShare(String fileId) throws SQLException {
		String arr = "";
		String sql = " SELECT `userId` FROM `cloud`.`filedata` where `fileId` = '"
				+ fileId + "'";
		Connection con = getDBConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			arr = rs.getString("userId");
		}
		System.out.println("The array in query is " + arr);
		return arr;

	}

	public static String getUploadedByFile(String fileId, int i) throws SQLException{
		String user = null;
		if(i == 1){
			String sql = "SELECT userId,size FROM (SELECT uploadBy,checkValue as size FROM `filedata` WHERE fileId = '"+fileId+"') newtable, useraccount  where newtable.uploadBy = useraccount.name ";
			Connection con = getDBConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				user = rs.getString("userId");
				user += "#" + rs.getString("size");
			}
		}
		if(i == 2){
			String sql = "SELECT `emailid` FROM (SELECT uploadBy,checkValue as size FROM `filedata` WHERE fileId = '"+fileId+"') newtable, useraccount  where newtable.uploadBy = useraccount.name ";
			Connection con = getDBConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				user = rs.getString("emailid");
			}
		}
		return user;
	}
	public static void encdec(String pass, String inputFile, String outputFile,
			int i) {
		if (i == 1) {
			FileEncryptor.encryptFile(pass, inputFile, outputFile);
			File inputfile = new File(inputFile);
			if (inputfile.exists()) {
				inputfile.delete();
			}
		}
		if (i == 2) {
			FileEncryptor.decryptFile(pass, inputFile, outputFile);
		}
	}
	
}
