package com.util;

public class CategoryModel {
	String catagoryId, catagoryDesc;

	public String getCatagoryId() {
		return catagoryId;
	}

	public void setCatagoryId(String catagoryId) {
		this.catagoryId = catagoryId;
	}

	public String getCatagoryDesc() {
		return catagoryDesc;
	}

	public void setCatagoryDesc(String catagoryDesc) {
		this.catagoryDesc = catagoryDesc;
	}
	
}
